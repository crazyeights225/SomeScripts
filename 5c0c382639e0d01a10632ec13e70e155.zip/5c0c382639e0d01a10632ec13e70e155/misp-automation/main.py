
import re
# import requests
import sys
from datetime import date
from os import path
from newspaper import Article

import configparser

# Optional can be phased out:
import csv
from colorama import Fore, Style

import os

from pymisp import ExpandedPyMISP, MISPEvent, PyMISP

from OTXv2 import OTXv2
from OTXv2 import IndicatorTypes

config = configparser.ConfigParser()
config.read('config.ini')

otx_api_key = config["OTX"]["api_key"]
otx = OTXv2(otx_api_key)

misp_api_key = config["MISP"]["api_key"]
misp_api_url = config["MISP"]["api_url"]
misp_api_verify_cert = bool(int(config["MISP"]["api_verifycert"]))

misp = PyMISP(misp_api_url, misp_api_key, misp_api_verify_cert, debug=False)
misp_ext = ExpandedPyMISP(misp_api_url, misp_api_key, misp_api_verify_cert, debug=False)

# Location of saved  reports in txt format:
SAVED_REPORTS = "backups"

# Convert the ioc category from the otx format to misp format:
otx_ioc_conversion = {
    "filehash-sha1": "sha1",
    "filehash-md5":  "md5",
    "filehash-sha256": "sha256",
    "filehash-pehash": "pehash",
    "filehash-imphash": "imphash",
    "filepath": "filename",
    "hostname": "hostname",
    "domain": "domain",
    "email": "email",
    "cve": "vulnerability",
    "cidr": "ip-src",
    "ipv4": "ip-src",
    "ipv6": "ip-src",
    "mutex": "mutex",
    "nids": "drop",
    "uri": "uri",
    "yara": "drop",
    "ja3": "drop",
    "osquery": "drop",
    "sslcertfingerprint": "",
    "bitcoinaddress": "btc"
}

def format_list(l):
    for i in l:
        print("- "+i)

class ThreatObj:
    def __init__(self, article_title, article, pulse_id):
        self.pulse_id = pulse_id
        self.misp_id = ""

        self.feed = "AlienVault"
        self.tlp = "WHITE"
        self.documents =  article

        self.adversary = ""
        self.target_countries = []
        self.attack_ids = []
        self.inidicators = []
        self.date = ""

        self.title = article_title
        self.description = ""
        self.wwc = ""

    def to_term(self):
        print("\n\n")
        print(Fore.CYAN + "Pulse ID:" + Fore.RESET + str(self.pulse_id)+ ", " + Fore.CYAN + "MISP ID: " + Fore.RESET + str(self.misp_id))
        print(Fore.RED + '{0} | {1}'.format(self.title, self.date))
        print(Fore.RESET + "Feed: " + self.feed)
        print("Source: "+self.documents)
        print("Adversary: "+self.adversary)
        print("\nDescription: [TO DO]\n")
        print(Fore.CYAN+"Target Countries: "+Fore.RESET)
        format_list(self.target_countries)
        print("")
        print(Fore.CYAN+"TTPS: "+Fore.RESET)
        format_list(self.attack_ids)
        print("")
        print("Why should we care about this as a CTI team:\n[TO DO]")

# This function is ugly
# We must reformat alot of the data we recieve from alienvault for misp
def pull_otx_data(event_obj, threat_obj, pulse_id):
    # Get all the indicators associated with a pulse
    pulse = otx.get_pulse_details(pulse_id)

    # Add targeted countries via misp-galaxy country
    if "targeted_countries" in pulse:
        pulse_countries = pulse["targeted_countries"]
        threat_obj.target_countries = pulse_countries

        for country in pulse_countries:
            event_obj.add_tag('misp-galaxy:Country="{0}"'.format(country))

        print("[INFO] Targeted countries added to MISP Event")
    else:
        print("[INFO] Feed AlienVault reported no targeted countries")

    # Get attack ids from pulse, convert them to MISP format, add them to MISP event
    if "attack_ids" in pulse:
        pulse_attack_ids = pulse["attack_ids"]
        ttps = get_ttps_from_attack_ids(pulse_attack_ids)
        threat_obj.attack_ids = ttps

        for ttp in ttps:
            event_obj.add_tag(ttp)

        print("[INFO] Attack IDS added to MISP Event")
    else:
        print("[ERROR] Feed Alienvault reported no attack_ids")

    # This is where it gets ugly:
    # Indicators must be properly categorized, before they can be put into misp
    if "indicators" in pulse:
        indicators = pulse["indicators"]
        for i in indicators:
            ioc_t = i["type"].lower()

            # SSL Cert Fingerprints are not classified in OTX, but they are in MISP
            # They must be classified before they can be put into MISP
            if ioc_t == "sslcertfingerprint":
                if len(i["indicator"]) == 59:
                    ioc_t = "x509-fingerprint-sha1"
                    event_obj.add_attribute(ioc_t, i["indicator"])

                elif len(i["indicator"]) == 95:
                    ioc_t = "x509-fingerprint-sha256"
                    event_obj.add_attribute(ioc_t, i["indicator"])
                else:
                    print("[ERROR] Unknown SSL Cert Fingerpint type "+i["indicator"])

            elif ioc_t in otx_ioc_conversion:
                ioc_type = otx_ioc_conversion[ioc_t]
                # Using drop allows for things such as YARA indicators to be filtered out, because they are unlikely to be used
                if ioc_type != "drop":
                    event_obj.add_attribute(ioc_type, i["indicator"])
            else:
                print("[ERROR] unknown IOC type: "+ioc_t)
        print("[INFO] Indicators added to MISP Event Object")
    else:
        print("[ERROR] No indicators were reported by AlienVault, this is definitely an error")

    # Other info:
    if "adversary" in pulse:
        threat_obj.adversary = pulse["adversary"]

    return event_obj, threat_obj


def to_misp(article_title, article_text, article_url, pulse_id):
    # Create an event
    event_obj = MISPEvent()
    event_obj.distribution = 0 # args.distrib
    event_obj.threat_level_id = 3 # args.threat
    event_obj.analysis = 2  # args.analysis
    event_obj.info = "{0}: {1}".format("Auto-generated", article_title)

    event_obj.add_tag("tlp:white")

    threat_obj = ThreatObj(article_title, article_url, pulse_id)

    today = date.today()

    event_obj.set_date(today)
    threat_obj.date = today

    event_obj, threat_obj = pull_otx_data(event_obj, threat_obj, pulse_id)

    event = misp_ext.add_event(event_obj, pythonify=False)
    
    event_id = event['Event']['id']
    threat_obj.misp_id = event['Event']['id']

    # Free Text:
    parsed_text = misp_ext.freetext(event_id, article_text)
    # Post-processing:
    #registered_indicators = []
    #for p in parsed_text:
    #    registered_indicators.append(p['value'])

    #print(event_obj.to_json())
    threat_obj.to_term()

    print("[INFO] Done....")

import json
def get_ttps_from_attack_ids(attack_ids):
    ttp_tag_file = "ttps.json"
    ttp_tags = []
    f = open(ttp_tag_file, "r")
    ttp_tags_json = json.load(f)
    for ai in attack_ids:
        ttp_tags.append(ttp_tags_json[ai])

    f.close()
    return ttp_tags


# Not being used:
# Look for ttps in text as well:
def validate_ttps(body_text):
    # check ttps
    ttp_re = re.compile('T[0-9]{4}(\.[0-9]{3})?')
    ttps = []
    i = 0
    while(re.search(ttp_re, body_text) != None):
        ttps.append(re.group(i))
        i+=1
    return ttps


# TO DO: Add exception handling:
def retrieve_from_file(file_name):
    try:
        f = open(file_name, 'r')
        txt = f.read()
        f.close()
        p = txt.split('\n', 1)
        return p[0], p[1]
    except Exception as e:
        print("[ERROR] Saved article could not be opened!")
        return None, None

def generate_filename(url):
    if url[-1] == "/":
        url = url[:-1]

    url_parts = url.split("/")
    file_name = url_parts[2] + url_parts[-1]
    file_name = "{0}.txt".format(file_name.replace(".", ""))
    return file_name

def save_to_file(title, url, page_text):
    file_name = generate_filename(url)

    try:
        f = open(path.join(SAVED_REPORTS, file_name), "w")
        page_text = title + "\n" + page_text

        f.write(page_text)
        f.close()
        print("[INFO] Writing {0} to file {1}".format(title, path.join(SAVED_REPORTS, file_name)))

    except Exception as e:
        print("[ERROR] Exception: %s" % e)


def parse_page(url):
    article = Article(url)
    try:
        article.download()
        article.parse()

        title = article.title
        page_text = article.text
        save_to_file(title, url, page_text)
        return (title, page_text)

    except Exception as e:
        print("[ERROR] Exception %s" % e)
        return (None, None)


# USE AS FALLBACK, once exception handling is added above (?)
"""
def parse_page(url):
    resp = requests.get(url)
    if resp.status_code == "200":
        resp_text = resp.text

        # get page title:
        title_re = re.search('\<\W*title\W*(.*)</title', resp_text, re.IGNORECASE)
        title = re.group(1)

        body_re = re.search('\<body(.*)\>((.|\n)*)\<\/body\>', resp_text)
        body_text = body_re.group(2)
        tag_re = re.compile(r'(<!--.*?-->|<[^>]*>)')

        # strip tags from html
        no_tags = tag_re.sub('', body_text)

        save_to_file(title, no_tags)

    else:
        print("[ERROR] The website returned an unexpected response")

"""

# https://otx.alienvault.com/pulse/60e02f9e498dfdf25caf7753
# https://www.bleepingcomputer.com/news/security/revil-ransomware-hits-1-000-plus-companies-in-msp-supply-chain-attack/

def parse_csv(file_name):
    with open(file_name, 'r') as f:
        cr = csv.reader(f, delimiter=",")
        for row in cr:
            if row[0] == "todo":
                return row[1],row[2]
    return None, None


def main(argv):
    if len(argv) == 0:
        print("[ERROR] Expected format intake.py <url> <pulse_id>")
        print("or main.py <csv>")
        return
    elif len(argv) == 1:
        csv_file = argv[0]
        url, pulse_id = parse_csv(csv_file)
    else:
        url = argv[0]
        pulse_id = argv[1]

    print(url)
    print(pulse_id)

    fn = os.path.join(SAVED_REPORTS, generate_filename(url))
    if os.path.exists(fn):
        title, page_text = retrieve_from_file(fn)
        print("[INFO] Report text file already exists")
    else:
        title, page_text = parse_page(url)

    to_misp(title, page_text, url, pulse_id)

if __name__ == "__main__":
    main(sys.argv[1:])
