
## MISP Automation

- Put data into misp

```
python3 main.py threat-queue.py
python3 main.py <url> <pulse>
```

TO DO:
- bugs
	- phone no. and useragents as urls
- formatting

